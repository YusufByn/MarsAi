import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import JuryDetails from './pages/user/JuryDetails';
import AllJury from './pages/user/AllJury';
import NewsletterAdmin from './pages/admin/NewsletterAdmin';
import Player from './pages/playerVideo/player';
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';
import Navbar from './components/layout/Navbar';
import Footer from './components/layout/Footer';

function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-black flex flex-col">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/jury" element={<AllJury />} />
            <Route path="/jury/profil/:id" element={<JuryDetails />} />
            <Route path="/admin/newsletter" element={<NewsletterAdmin />} />
            <Route path="/video/player" element={<Player />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </BrowserRouter>
  );
}

export default App;
